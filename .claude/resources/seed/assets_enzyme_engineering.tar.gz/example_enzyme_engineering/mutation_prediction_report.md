# IS621 Bridge Recombinase: Multi-Method Variant Effect Prediction Report

## Executive Summary

This report presents a comprehensive computational screen of all possible single amino acid substitutions in the IS621 bridge recombinase (326 aa, *E. coli*) using four complementary protein language model (PLM) and structure-based approaches. The goal is to identify mutations that could improve enzymatic (recombinase) activity while preserving the essential DEDD catalytic tetrad and overall protein fold.

**Key Finding:** From 6,194 single-point mutations scored, **26 mutations** were predicted beneficial by all four methods, and **135 mutations** were predicted beneficial by ≥3 methods. After filtering for catalytic residue protection, structural confidence, and biochemical compatibility, a curated list of **20 top candidates** is presented for experimental testing.

---

## 1. Methods

### 1.1 ESM-2 Masked Marginal Scoring (Zero-Shot)
- **Model:** ESM-2 (esm2_t33_650M_UR50D, 650M parameters)
- **Approach:** For each of 326 positions, the wild-type residue was masked and the model predicted a probability distribution over all 20 amino acids. The log-likelihood ratio (LLR) = log P(mutant|context) − log P(wildtype|context) quantifies whether the model considers the mutation more favorable (+) or less favorable (−) than wild-type in the evolutionary context.
- **Forward passes:** 326 (one per position, batched 8 at a time)
- **Runtime:** ~158 seconds (CPU)

### 1.2 ESM-1v Masked Marginal Scoring
- **Model:** ESM-1v (esm1v_t33_650M_UR90S_1, 650M parameters)
- **Approach:** Same masked marginal protocol as ESM-2. ESM-1v was specifically trained for variant effect prediction using the UR90S dataset, providing a complementary evolutionary perspective.
- **Runtime:** ~117 seconds (CPU)

### 1.3 ESM-C Autoregressive Scoring
- **Model:** ESM-C (esmc_300m, 300M parameters, EvolutionaryScale)
- **Approach:** The full wild-type sequence was passed through ESM-C to obtain per-position logits. Unlike masked marginal scoring, this evaluates each position in the context of all other wild-type residues simultaneously ("teacher forcing"). LLRs were computed from the softmax-normalized logits.
- **Key difference:** ESM-C sees the complete sequence context rather than a masked version, capturing different aspects of sequence fitness.

### 1.4 ProteinMPNN Inverse Folding
- **Model:** ProteinMPNN (vanilla_model_weights)
- **Input:** ESMFold-predicted structure from Phase 1 (mean pLDDT = 0.90)
- **Approach:** 100 sequences were designed at temperature 0.1 for the IS621 backbone. Per-position amino acid frequency profiles were computed from the designed sequences. Positions where MPNN strongly prefers a different residue than wild-type indicate structural optimization opportunities.
- **Sequence recovery:** 38.3%–45.4% (mean ~42.1%)

### 1.5 Structural Context
- **pLDDT scores** extracted from the ESMFold PDB B-factor column
- **Solvent accessible surface area (SASA)** computed with Biotite (ProtOr radii)
- **Distance to catalytic residues** (D11, E60, D102, D105 Cα atoms)
- **Domain assignment:** Catalytic (8–152), Linker (153–195), DNA-binding (196–280), C-terminal (281–326)

---

## 2. Results by Method

### 2.1 ESM-2 Zero-Shot Scoring
- **Total mutations scored:** 6,194
- **Mutations with positive LLR (predicted beneficial):** 114 (1.8%)
- **Top hit:** L168A (LLR = +5.01)
- **Key positions with strong positive signal:** L168, T152, N322, K290, S258, T271, K219
- **Positions where ESM-2 prefers non-WT:** 40/326 (12.3%)
- **Mean wild-type probability:** 0.811 (high overall conservation)
- **Mean positional entropy:** 0.682 bits

ESM-2 was the most conservative method, with only 1.8% of mutations predicted beneficial. Strong positive signals clustered in the linker domain (position 168) and at domain boundaries (position 152).

### 2.2 ESM-1v Variant Scoring
- **Mutations with positive LLR:** 647 (10.4%)
- **Top hit:** N99A (LLR = +6.70)
- **Key positions:** N99, E95, Q159, K219, M66, L218, H145, H138
- **Distinctive calls:** E95M/L/I (LLR > 5.7), K219F/I/V (LLR > 5.2)

ESM-1v was more permissive than ESM-2, particularly at catalytic domain positions near but not at the active site (e.g., E95, N99). It identified several positions in the catalytic vicinity where non-conservative substitutions may be tolerated.

### 2.3 ESM-C Scoring
- **Mutations with positive LLR:** 542 (8.8%)
- **Top hit:** M66H (LLR = +6.03)
- **Key positions:** M66, T12, S209, H125, H224, T152, T103, T185
- **Distinctive calls:** Strong signal for histidine replacements (H125, H224, H256)

ESM-C showed highest correlation with ESM-1v (Spearman ρ = 0.828) and identified several histidine positions in the catalytic and DNA-binding domains as candidates for substitution.

### 2.4 ProteinMPNN Inverse Folding
- **Positions where MPNN prefers non-WT:** 186/326 (57.1%)
- **Positions with 100% non-WT recovery:** D102P, T103E, A61D, R281A, C72A, S209A, I163L, S249P, I83V, T12V, T185I, V257P, N99E, R98T
- **Mean WT recovery:** 42.1%

**CRITICAL NOTE:** ProteinMPNN suggested D102P (100% frequency), but D102 is a catalytic residue and must NOT be mutated. This illustrates that MPNN optimizes for structural/energetic fitness without knowledge of catalytic function. All MPNN suggestions at catalytic positions (D11, E60, D102, D105) were excluded.

MPNN showed lowest correlation with the PLM methods (ρ = 0.20–0.37), providing genuinely orthogonal information about structural preferences vs. evolutionary fitness.

---

## 3. Method Correlation Analysis

| Method Pair | Spearman ρ | Interpretation |
|---|---|---|
| ESM-1v vs ESM-C | 0.828 | High — both capture evolutionary fitness |
| ESM-2 vs ESM-C | 0.627 | Moderate — similar but ESM-2 is more conservative |
| ESM-2 vs ESM-1v | 0.549 | Moderate — different training data (UR50D vs UR90S) |
| ESM-1v vs MPNN | 0.367 | Low — evolutionary vs structural signals |
| ESM-C vs MPNN | 0.312 | Low — complementary information |
| ESM-2 vs MPNN | 0.200 | Low — most orthogonal pair |

The PLM methods (ESM-2, ESM-1v, ESM-C) are moderately to highly correlated, reflecting shared evolutionary information. ProteinMPNN provides orthogonal structural information, making it a valuable complement. Mutations supported by both PLMs and MPNN have the strongest evidence.

---

## 4. Consensus Analysis

### Multi-Method Agreement Distribution
| Methods Positive | Number of Mutations | Percentage |
|---|---|---|
| 0 | 4,421 | 71.4% |
| 1 | 1,330 | 21.5% |
| 2 | 308 | 5.0% |
| 3 | 109 | 1.8% |
| 4 | 26 | 0.4% |

### Filtering Criteria for Final Candidates
1. **Protected positions excluded:** D11, E60, D102, D105 (DEDD catalytic tetrad)
2. **Minimum structure confidence:** pLDDT ≥ 0.60
3. **No new cysteines introduced:** Avoids unwanted disulfide bond formation
4. **Minimum method agreement:** ≥2 methods predicting beneficial

### Priority Scoring Formula
```
Priority = Consensus_Zscore × 1.0 + N_Methods_Positive × 0.3 + 
           Conservative_Bonus × 0.2 + Distal_Bonus × 0.2 + (pLDDT − 0.7) × 0.5
```

---

## 5. Top 20 Ranked Mutation Candidates

| Rank | Mutation | Domain | Exposure | pLDDT | ESM-2 LLR | ESM-1v LLR | ESM-C LLR | MPNN Freq | Methods+ | Priority | Rationale |
|------|----------|--------|----------|-------|-----------|------------|-----------|-----------|----------|----------|-----------|
| 1 | **L168A** | linker | surface | 0.91 | +5.01 | +2.81 | +2.92 | 83% | 4/4 | 4.46 | Coiled-coil linker position. L→A reduces hydrophobic bulk at surface; all 4 meth... |
| 2 | **T152L** | catalytic | buried | 0.91 | +4.13 | +1.75 | +3.75 | 97% | 4/4 | 4.19 | Junction of catalytic domain/linker. T→L at conserved position; MPNN strongly fa... |
| 3 | **H193R** | linker | surface | 0.93 | +1.17 | +2.60 | +0.95 | 89% | 4/4 | 4.03 | Linker domain surface. H→R (conservative positive charge); all 4 methods agree. ... |
| 4 | **S258L** | DNA_binding | buried | 0.88 | +3.64 | +0.25 | +1.98 | 79% | 4/4 | 3.88 | DNA-binding domain buried position. All 4 methods agree on substitution from pol... |
| 5 | **T152R** | catalytic | buried | 0.91 | +2.41 | +2.79 | +4.24 | 3% | 4/4 | 3.83 | Catalytic domain boundary. T→R; PLM methods strongly favor. Could improve electr... |
| 6 | **H224N** | DNA_binding | surface | 0.86 | +1.07 | +2.41 | +3.49 | 23% | 4/4 | 3.82 | DNA-binding domain surface. H→N reduces positive charge; all 4 methods agree. Ma... |
| 7 | **S45A** | catalytic | surface | 0.96 | +0.89 | +1.75 | +1.45 | 96% | 4/4 | 3.81 | Catalytic domain surface, distal from active site. S→A removes OH; all 4 methods... |
| 8 | **K290P** | C_terminal | surface | 0.89 | +4.28 | +1.28 | +3.00 | 5% | 4/4 | 3.79 | C-terminal extension surface. K→P; strong ESM2 and ESMC support. Proline may rig... |
| 9 | **S272T** | DNA_binding | surface | 0.94 | +0.07 | +0.06 | +0.99 | 85% | 4/4 | 3.77 | DNA-binding domain surface. S→T (conservative); all 4 methods support. Very high... |
| 10 | **S258R** | DNA_binding | buried | 0.88 | +3.90 | +0.90 | +1.43 | 14% | 4/4 | 3.72 | DNA-binding domain, partially buried. S→R; strong ESM2 support. May introduce be... |
| 11 | **L168K** | linker | surface | 0.91 | +2.16 | +3.56 | +0.38 | 12% | 4/4 | 3.71 | Coiled-coil linker surface. L→K; strong ESM1v support. Could improve solubility ... |
| 12 | **N322L** | C_terminal | surface | 0.74 | +0.79 | +1.57 | +2.37 | 62% | 4/4 | 3.70 | C-terminal extension. N→L; all 4 methods agree. C-terminal residue, may improve ... |
| 13 | **T271L** | DNA_binding | buried | 0.92 | +3.47 | +0.25 | +0.44 | 36% | 4/4 | 3.69 | DNA-binding domain core. T→L; strong ESM2 support. Improved hydrophobic core pac... |
| 14 | **L168E** | linker | surface | 0.91 | +4.31 | +1.29 | +1.16 | 5% | 4/4 | 3.67 | Coiled-coil linker surface. L→E; strong ESM2 signal. Charged residue could form ... |
| 15 | **D164E** | linker | surface | 0.94 | +0.14 | +0.33 | +1.42 | 65% | 4/4 | 3.67 | Linker domain surface, high confidence region (pLDDT 0.94). D→E (conservative); ... |
| 16 | **M298L** | C_terminal | buried | 0.94 | +1.57 | +2.24 | +0.87 | 1% | 4/4 | 3.62 | C-terminal extension buried. M→L (conservative); all 4 methods agree. High pLDDT... |
| 17 | **S209A** | DNA_binding | buried | 0.95 | -0.51 | +1.40 | +4.66 | 100% | 3/4 | 3.62 | DNA-binding domain core. S→A; very strong ESMC and MPNN support (100% MPNN). Ver... |
| 18 | **H224S** | DNA_binding | surface | 0.86 | +0.62 | +2.45 | +4.19 | 1% | 4/4 | 3.57 | DNA-binding domain surface. H→S; strong ESMC support. Reduces positive charge, m... |
| 19 | **T271A** | DNA_binding | buried | 0.92 | +2.36 | +2.05 | +2.20 | 1% | 4/4 | 3.55 | DNA-binding domain core. T→A; all 4 methods agree. High pLDDT (0.92). Core packi... |
| 20 | **N322R** | C_terminal | surface | 0.74 | +1.51 | +1.45 | +0.81 | 18% | 4/4 | 3.49 | C-terminal extension surface. N→R; all 4 methods agree. May improve surface char... |


### Detailed Candidate Descriptions

#### #1. L168A — Position 168, linker domain
- **Substitution type:** Conservative (L → A)
- **Structural context:** distal, surface, pLDDT = 0.91, distance to active site = 38.9 Å
- **Scores:** ESM-2 LLR = +5.014 | ESM-1v LLR = +2.813 | ESM-C LLR = +2.924 | MPNN freq = 83% (WT: 0%)
- **Rationale:** Coiled-coil linker position. L→A reduces hydrophobic bulk at surface; all 4 methods agree. May improve inter-subunit dynamics in homotetramer.

#### #2. T152L — Position 152, catalytic domain
- **Substitution type:** Non-conservative (T → L)
- **Structural context:** distal, buried, pLDDT = 0.91, distance to active site = 40.4 Å
- **Scores:** ESM-2 LLR = +4.132 | ESM-1v LLR = +1.753 | ESM-C LLR = +3.754 | MPNN freq = 97% (WT: 0%)
- **Rationale:** Junction of catalytic domain/linker. T→L at conserved position; MPNN strongly favors (97%). Could stabilize domain boundary packing.

#### #3. H193R — Position 193, linker domain
- **Substitution type:** Conservative (H → R)
- **Structural context:** distal, surface, pLDDT = 0.93, distance to active site = 34.0 Å
- **Scores:** ESM-2 LLR = +1.172 | ESM-1v LLR = +2.599 | ESM-C LLR = +0.954 | MPNN freq = 89% (WT: 0%)
- **Rationale:** Linker domain surface. H→R (conservative positive charge); all 4 methods agree. May improve DNA binding or subunit contacts.

#### #4. S258L — Position 258, DNA binding domain
- **Substitution type:** Non-conservative (S → L)
- **Structural context:** distal, buried, pLDDT = 0.88, distance to active site = 20.0 Å
- **Scores:** ESM-2 LLR = +3.636 | ESM-1v LLR = +0.249 | ESM-C LLR = +1.975 | MPNN freq = 79% (WT: 0%)
- **Rationale:** DNA-binding domain buried position. All 4 methods agree on substitution from polar to hydrophobic; could improve core packing.

#### #5. T152R — Position 152, catalytic domain
- **Substitution type:** Non-conservative (T → R)
- **Structural context:** distal, buried, pLDDT = 0.91, distance to active site = 40.4 Å
- **Scores:** ESM-2 LLR = +2.408 | ESM-1v LLR = +2.788 | ESM-C LLR = +4.242 | MPNN freq = 3% (WT: 0%)
- **Rationale:** Catalytic domain boundary. T→R; PLM methods strongly favor. Could improve electrostatic interactions at domain junction.

#### #6. H224N — Position 224, DNA binding domain
- **Substitution type:** Non-conservative (H → N)
- **Structural context:** distal, surface, pLDDT = 0.86, distance to active site = 24.6 Å
- **Scores:** ESM-2 LLR = +1.067 | ESM-1v LLR = +2.410 | ESM-C LLR = +3.492 | MPNN freq = 23% (WT: 0%)
- **Rationale:** DNA-binding domain surface. H→N reduces positive charge; all 4 methods agree. May modulate DNA affinity for optimal catalysis.

#### #7. S45A — Position 45, catalytic domain
- **Substitution type:** Non-conservative (S → A)
- **Structural context:** distal, surface, pLDDT = 0.96, distance to active site = 18.5 Å
- **Scores:** ESM-2 LLR = +0.894 | ESM-1v LLR = +1.747 | ESM-C LLR = +1.453 | MPNN freq = 96% (WT: 0%)
- **Rationale:** Catalytic domain surface, distal from active site. S→A removes OH; all 4 methods agree. Simplifies surface, may reduce non-specific interactions.

#### #8. K290P — Position 290, C terminal domain
- **Substitution type:** Non-conservative (K → P)
- **Structural context:** distal, surface, pLDDT = 0.89, distance to active site = 37.2 Å
- **Scores:** ESM-2 LLR = +4.278 | ESM-1v LLR = +1.277 | ESM-C LLR = +3.002 | MPNN freq = 5% (WT: 0%)
- **Rationale:** C-terminal extension surface. K→P; strong ESM2 and ESMC support. Proline may rigidify loop, improving structural stability.

#### #9. S272T — Position 272, DNA binding domain
- **Substitution type:** Conservative (S → T)
- **Structural context:** distal, surface, pLDDT = 0.94, distance to active site = 40.7 Å
- **Scores:** ESM-2 LLR = +0.065 | ESM-1v LLR = +0.063 | ESM-C LLR = +0.990 | MPNN freq = 85% (WT: 0%)
- **Rationale:** DNA-binding domain surface. S→T (conservative); all 4 methods support. Very high pLDDT (0.94). Minimal risk, potential stability gain.

#### #10. S258R — Position 258, DNA binding domain
- **Substitution type:** Non-conservative (S → R)
- **Structural context:** distal, buried, pLDDT = 0.88, distance to active site = 20.0 Å
- **Scores:** ESM-2 LLR = +3.900 | ESM-1v LLR = +0.895 | ESM-C LLR = +1.430 | MPNN freq = 14% (WT: 0%)
- **Rationale:** DNA-binding domain, partially buried. S→R; strong ESM2 support. May introduce beneficial salt bridge.

#### #11. L168K — Position 168, linker domain
- **Substitution type:** Non-conservative (L → K)
- **Structural context:** distal, surface, pLDDT = 0.91, distance to active site = 38.9 Å
- **Scores:** ESM-2 LLR = +2.158 | ESM-1v LLR = +3.556 | ESM-C LLR = +0.378 | MPNN freq = 12% (WT: 0%)
- **Rationale:** Coiled-coil linker surface. L→K; strong ESM1v support. Could improve solubility and inter-subunit contacts in tetramer.

#### #12. N322L — Position 322, C terminal domain
- **Substitution type:** Non-conservative (N → L)
- **Structural context:** distal, surface, pLDDT = 0.74, distance to active site = 41.3 Å
- **Scores:** ESM-2 LLR = +0.787 | ESM-1v LLR = +1.575 | ESM-C LLR = +2.371 | MPNN freq = 62% (WT: 0%)
- **Rationale:** C-terminal extension. N→L; all 4 methods agree. C-terminal residue, may improve stability of extension region.

#### #13. T271L — Position 271, DNA binding domain
- **Substitution type:** Non-conservative (T → L)
- **Structural context:** distal, buried, pLDDT = 0.92, distance to active site = 38.0 Å
- **Scores:** ESM-2 LLR = +3.468 | ESM-1v LLR = +0.249 | ESM-C LLR = +0.441 | MPNN freq = 36% (WT: 0%)
- **Rationale:** DNA-binding domain core. T→L; strong ESM2 support. Improved hydrophobic core packing.

#### #14. L168E — Position 168, linker domain
- **Substitution type:** Non-conservative (L → E)
- **Structural context:** distal, surface, pLDDT = 0.91, distance to active site = 38.9 Å
- **Scores:** ESM-2 LLR = +4.311 | ESM-1v LLR = +1.288 | ESM-C LLR = +1.157 | MPNN freq = 5% (WT: 0%)
- **Rationale:** Coiled-coil linker surface. L→E; strong ESM2 signal. Charged residue could form beneficial salt bridge.

#### #15. D164E — Position 164, linker domain
- **Substitution type:** Conservative (D → E)
- **Structural context:** distal, surface, pLDDT = 0.94, distance to active site = 41.2 Å
- **Scores:** ESM-2 LLR = +0.144 | ESM-1v LLR = +0.331 | ESM-C LLR = +1.424 | MPNN freq = 65% (WT: 2%)
- **Rationale:** Linker domain surface, high confidence region (pLDDT 0.94). D→E (conservative); all 4 methods agree. Minimal risk modification.

#### #16. M298L — Position 298, C terminal domain
- **Substitution type:** Conservative (M → L)
- **Structural context:** distal, buried, pLDDT = 0.94, distance to active site = 31.6 Å
- **Scores:** ESM-2 LLR = +1.566 | ESM-1v LLR = +2.236 | ESM-C LLR = +0.866 | MPNN freq = 1% (WT: 0%)
- **Rationale:** C-terminal extension buried. M→L (conservative); all 4 methods agree. High pLDDT (0.94). Removes oxidation-prone methionine.

#### #17. S209A — Position 209, DNA binding domain
- **Substitution type:** Non-conservative (S → A)
- **Structural context:** distal, buried, pLDDT = 0.95, distance to active site = 28.4 Å
- **Scores:** ESM-2 LLR = -0.513 | ESM-1v LLR = +1.403 | ESM-C LLR = +4.664 | MPNN freq = 100% (WT: 0%)
- **Rationale:** DNA-binding domain core. S→A; very strong ESMC and MPNN support (100% MPNN). Very high pLDDT (0.95). Likely structural improvement.

#### #18. H224S — Position 224, DNA binding domain
- **Substitution type:** Non-conservative (H → S)
- **Structural context:** distal, surface, pLDDT = 0.86, distance to active site = 24.6 Å
- **Scores:** ESM-2 LLR = +0.625 | ESM-1v LLR = +2.454 | ESM-C LLR = +4.192 | MPNN freq = 1% (WT: 0%)
- **Rationale:** DNA-binding domain surface. H→S; strong ESMC support. Reduces positive charge, may optimize DNA contacts.

#### #19. T271A — Position 271, DNA binding domain
- **Substitution type:** Non-conservative (T → A)
- **Structural context:** distal, buried, pLDDT = 0.92, distance to active site = 38.0 Å
- **Scores:** ESM-2 LLR = +2.363 | ESM-1v LLR = +2.047 | ESM-C LLR = +2.203 | MPNN freq = 1% (WT: 0%)
- **Rationale:** DNA-binding domain core. T→A; all 4 methods agree. High pLDDT (0.92). Core packing optimization.

#### #20. N322R — Position 322, C terminal domain
- **Substitution type:** Non-conservative (N → R)
- **Structural context:** distal, surface, pLDDT = 0.74, distance to active site = 41.3 Å
- **Scores:** ESM-2 LLR = +1.512 | ESM-1v LLR = +1.451 | ESM-C LLR = +0.812 | MPNN freq = 18% (WT: 0%)
- **Rationale:** C-terminal extension surface. N→R; all 4 methods agree. May improve surface charge distribution.

---

## 6. Engineering Recommendations

### 6.1 Tier 1: High-Confidence, Low-Risk (Test First)
These mutations have all 4 methods in agreement, conservative or surface-located, and high structural confidence:

1. **L168A** — Strongest consensus across all methods (LLR +5.0 ESM-2). Linker domain surface position, likely modulates inter-subunit dynamics.
2. **H193R** — Conservative His→Arg at linker surface. High pLDDT (0.93). May enhance tetramer stability.
3. **S272T** — Conservative Ser→Thr at DNA-binding surface. Extremely high confidence (pLDDT 0.94). Minimal risk.
4. **D164E** — Conservative Asp→Glu at linker surface. All 4 methods agree. Negligible structural perturbation expected.
5. **M298L** — Conservative Met→Leu in C-terminal core. Removes oxidation-susceptible methionine. High pLDDT (0.94).

### 6.2 Tier 2: Strong Signal, Moderate Risk
These have strong multi-method support but involve non-conservative changes at buried or functionally important positions:

6. **T152L** — Domain boundary; very strong MPNN signal (97%). Could significantly alter domain packing.
7. **S258L/R** — DNA-binding domain buried; strong ESM-2 signal. Two alternative substitutions at same position.
8. **H224N/S** — DNA-binding domain surface; may modulate DNA affinity.
9. **K290P** — C-terminal surface; may rigidify a loop region.
10. **S209A** — 100% MPNN preference; very high pLDDT (0.95). Structure-based evidence is exceptionally strong.

### 6.3 Tier 3: Exploratory (Higher Risk, Higher Reward)
These have divergent method signals but strong support from at least 2-3 methods:

11. **L168K/E** — Same position as #1 but more radical substitutions. Could create novel salt bridges.
12. **T271L/A** — DNA-binding domain core. May improve stability but carries more risk.
13. **H145R** — Catalytic domain buried. Very strong ESM-1v signal (LLR +4.3) but ESM-2 disagrees.
14. **K219A/G** — DNA-binding surface. Low pLDDT (0.67) region—may be flexible and tolerant of changes.

### 6.4 Combinatorial Strategy
Based on the analysis, the following multi-mutant combinations are suggested for a second round, after validating singles:

- **Stability combo:** L168A + S272T + M298L (all conservative, different domains)
- **Linker optimization:** L168A + H193R + D164E (clustered in linker)
- **DNA-binding tuning:** H224N + S258R + T271A (DNA-binding domain)
- **Full optimization:** L168A + T152L + S209A + M298L (highest consensus across protein)

### 6.5 Positions to Avoid
- **D11, E60, D102, D105** — Catalytic tetrad (DEDD motif). Any mutation ablates activity.
- **Positions 8–14** — Directly adjacent to D11, very close to Mg²⁺ coordination.
- **C58, C72, C113** — Existing cysteines; mutations could disrupt structural disulfides or metal coordination.
- **Positions with pLDDT < 0.5** — Uncertain structure, prediction unreliable.

---

## 7. Caveats and Limitations

1. **No explicit activity modeling:** PLM scores reflect evolutionary fitness (conservation/co-evolution), not enzymatic activity directly. A mutation that improves fold stability may not improve catalysis.
2. **Predicted structure:** The ESMFold model used for ProteinMPNN has no bound DNA or Mg²⁺. Structure-based predictions cannot account for substrate interactions.
3. **Monomeric analysis:** IS621 functions as a homotetramer. Mutations at subunit interfaces may have cooperative effects not captured here.
4. **Temperature = 0.1 for MPNN:** Low temperature biases toward the MPNN-optimal sequence. Higher temperature sampling might reveal additional diversity.
5. **No epistatic effects:** Single-mutation analysis cannot predict combinatorial effects. Double mutants should be validated experimentally.

---

## 8. Output Files

| File | Description |
|------|-------------|
| `top20_mutation_candidates.csv` | Ranked top 20 candidates with all scores and rationale |
| `all_variant_scores_merged.csv` | Complete dataset of 6,194 mutations with all 4 method scores |
| `variant_effect_landscape.png` | Multi-panel overview of variant effect predictions |
| `esm2_variant_heatmap.png` | Position × amino acid heatmap of ESM-2 LLR scores |
| `consensus_analysis.png` | Method correlation and consensus analysis figures |
| `esm2_variant_scores.csv` | Raw ESM-2 masked marginal scores |
| `esm1v_variant_scores.csv` | Raw ESM-1v masked marginal scores |
| `esmc_variant_scores.csv` | Raw ESM-C autoregressive scores |
| `mpnn_variant_scores.csv` | Raw ProteinMPNN frequency-based scores |
| `structural_context.csv` | Per-position pLDDT, SASA, domain, and proximity annotations |

---

*Report generated using ESM-2 (650M), ESM-1v (650M), ESM-C (300M), and ProteinMPNN on the ESMFold-predicted structure of IS621 transposase / bridge recombinase (326 aa, E. coli).*
