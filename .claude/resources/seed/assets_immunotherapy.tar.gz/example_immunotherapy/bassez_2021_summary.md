
# Bassez et al. 2021 - Comprehensive Study Summary

## Paper Citation
**Title:** A single-cell map of intratumoral changes during anti-PD1 treatment of patients with breast cancer  
**Authors:** Bassez A, Vos H, Van Dyck L, et al.  
**Journal:** Nature Medicine, Volume 27, Issue 5, Pages 820-832  
**Publication Date:** May 2021  
**DOI:** [10.1038/s41591-021-01323-8](https://doi.org/10.1038/s41591-021-01323-8)  
**PMID:** [33958794](https://pubmed.ncbi.nlm.nih.gov/33958794/)  
**Citation Count:** 837+ (highly influential)

---

## 1. Study Design

### Patient Cohort
| Cohort | N | Treatment Protocol |
|--------|---|-------------------|
| **Cohort 1 (Treatment-naive)** | n=29 | Anti-PD1 before surgery (no prior chemotherapy) |
| **Cohort 2 (Post-chemotherapy)** | n=11 | Neoadjuvant chemotherapy BEFORE anti-PD1 |
| **Total** | n=40 | |

### Breast Cancer Subtypes
- **Hormone receptor-positive (HR+)** breast cancer
- **Triple-negative breast cancer (TNBC)**

### Sample Collection Timepoints
- **Pre-treatment biopsy**: Before anti-PD1 administration
- **On-treatment biopsy**: During anti-PD1 treatment
- **Paired samples**: Pre- vs. on-treatment from same patients

### Technologies Used
1. **Single-cell RNA sequencing (scRNA-seq)** - transcriptome profiling
2. **Single-cell T cell receptor (TCR) sequencing** - clonality analysis
3. **CITE-seq (proteome profiling)** - surface protein expression

---

## 2. Cell Types Identified and Proportions

The study identified multiple cell populations in the tumor microenvironment:

### Major Cell Lineages
- **T cells** (CD4+ and CD8+)
- **B cells**
- **Myeloid cells** (macrophages, dendritic cells)
- **Cancer cells/epithelial cells**
- **Stromal cells**

### T Cell Subpopulations (Key Focus)
| Subtype | Key Markers | Characteristics |
|---------|-------------|-----------------|
| **Exhausted CD8+ T cells** | PRF1, GZMB, HAVCR2 (TIM-3), LAG3, CXCL13 | Cytotoxic but exhausted |
| **Pre-effector/memory CD8+ T cells** | TCF7+, GZMK+ | Undifferentiated, stem-like |
| **Cytotoxic CD8+ T cells** | PRF1+, GZMB+, CD107a+ | Active tumor-killing |
| **Tfh-like CD4+ T cells** | BCL6+, CXCR5+, CXCL13+ | Follicular helper phenotype |
| **Th1 CD4+ T cells** | IFNG+ | Pro-inflammatory |
| **Tregs** | FOXP3+, IL2RA+ | Regulatory |

### Myeloid Subpopulations
| Subtype | Key Markers | Association with Response |
|---------|-------------|---------------------------|
| **PD-L1+ Dendritic Cells** | CD274 (PD-L1)+, mature DC markers | POSITIVE - correlate with T cell expansion |
| **CCR2+ Macrophages** | CCR2+ | POSITIVE |
| **MMP9+ Macrophages** | MMP9+ | POSITIVE |
| **CX3CR1+ Macrophages** | CX3CR1+, C3+ | NEGATIVE - inhibitory phenotype |
| **Immunoregulatory DCs** | PD-L1+, mature | Associated with good response |

---

## 3. Key Cell Populations Changed with Treatment

### T Cell Expansion Patterns
**Critical Finding:** Approximately **one-third of tumors** contained PD1-expressing T cells that clonally expanded upon anti-PD1 treatment.

### Expanded Populations (Responders)
| Cell Type | Expansion Pattern | Notes |
|-----------|-------------------|-------|
| **Exhausted CD8+ T cells** | ⬆️ EXPANDED | Main expanding population; TCR clonal expansion |
| **CXCL13+ CD8+ T cells** | ⬆️ EXPANDED | Critical immune homing signature |
| **Tfh-like CD4+ T cells** | ⬆️ EXPANDED | BCL6+, CXCR5+ |
| **Th1 CD4+ T cells** | ⬆️ EXPANDED | IFNG+ |

### Contracted/Unchanged Populations
| Cell Type | Pattern | Notes |
|-----------|---------|-------|
| **TCF7+ GZMK+ pre-effector T cells** | Associated with NON-response | Inversely correlated with expansion |
| **CX3CR1+ C3+ macrophages** | Inhibitory | Associated with poor response |

---

## 4. T Cell Subtypes and Response Association

### CD8+ T Cell States
| State | Markers | Association |
|-------|---------|-------------|
| **Tumor-reactive exhausted** | HAVCR2 (TIM-3)+, LAG3+, PD-1+, GZMB+, PRF1+ | EXPANDERS - respond to anti-PD1 |
| **CXCL13-expressing** | CXCL13+, CXCR5+ | Strong marker of response |
| **TCF7+ progenitor/stem-like** | TCF7+, GZMK+, IL7R+ | NON-EXPANDERS - poor response |
| **Tissue-resident memory** | CD103+, CD39+ | Associated with tumor reactivity |

### CD4+ T Cell States
| State | Markers | Association |
|-------|---------|-------------|
| **T follicular helper (Tfh)-like** | BCL6+, CXCR5+, CXCL13+, ICOS+ | EXPANDERS - respond to anti-PD1 |
| **Th1** | IFNG+, TBX21+ | EXPANDERS |
| **Regulatory T cells (Tregs)** | FOXP3+, IL2RA+ | Variable |

---

## 5. Marker Genes and Signatures

### Expansion-Associated Genes (RESPONDERS)
**CD8+ T cells:**
- **Cytotoxicity:** PRF1, GZMB, GNLY, NKG7
- **Exhaustion:** HAVCR2 (TIM-3), LAG3, PDCD1 (PD-1), CTLA4, TIGIT
- **Immune homing:** CXCL13, CXCR5
- **Tissue residence:** ITGAE (CD103), ENTPD1 (CD39)
- **Effector:** IFNG

**CD4+ T cells:**
- **Tfh markers:** BCL6, CXCR5, CXCL13, ICOS, SH2D1A
- **Th1 markers:** IFNG, TBX21

### Non-Expansion-Associated Genes (NON-RESPONDERS)
**T cells:**
- TCF7 (TCF1)
- GZMK
- IL7R
- LEF1
- CCR7
- SELL

**Macrophages:**
- CX3CR1
- C3
- APOE
- TREM2

---

## 6. Predictive Biomarkers Proposed

### Pre-Treatment Biomarkers POSITIVELY Associated with T Cell Expansion

| Biomarker | Cell Type | Predictive Value |
|-----------|-----------|------------------|
| **PD-L1+ DCs** | Immunoregulatory dendritic cells | Higher frequency = better response |
| **CCR2+ macrophages** | Myeloid | Positive correlation |
| **MMP9+ macrophages** | Myeloid | Positive correlation |
| **MHC-I/II expression on cancer cells** | Tumor cells | Higher = better response |
| **Baseline CD8+ T cell infiltration** | T cells | Higher = better response |
| **CXCL13 expression** | T cells | Predictor of expansion |

### Pre-Treatment Biomarkers NEGATIVELY Associated with T Cell Expansion

| Biomarker | Cell Type | Predictive Value |
|-----------|-----------|------------------|
| **TCF7+ GZMK+ T cells** | Pre-effector/memory T cells | Higher = worse response |
| **CX3CR1+ macrophages** | Inhibitory macrophages | Higher = worse response |
| **C3+ macrophages** | Complement-expressing macrophages | Higher = worse response |

### Gene Signatures Proposed
1. **T cell expansion signature** - genes upregulated in expanding clones
2. **Pre-treatment predictive signature** - baseline TME features predicting response
3. **Exhaustion vs. dysfunction distinction** - separating responsive vs. terminal exhaustion

---

## 7. Key Biological Conclusions

### Main Findings

1. **Clonal T Cell Expansion is Key to Response**
   - Anti-PD1 induces clonal expansion of pre-existing tumor-reactive T cells
   - Expansion occurs irrespective of breast cancer subtype (HR+ or TNBC)
   - Only ~1/3 of patients showed significant expansion

2. **"Good Exhaustion" Phenotype**
   - Responding T cells have exhaustion markers (TIM-3, LAG3) BUT retain cytotoxic function
   - These cells express CXCL13, a key chemokine for immune cell recruitment
   - Exhausted phenotype is NOT synonymous with dysfunction in this context

3. **TCF7+ T Cells Are NOT the Responders**
   - Contrary to some models, TCF7+ "progenitor exhausted" T cells were NOT the main expanders
   - Pre-effector/memory T cells (TCF7+, GZMK+) were INVERSELY correlated with expansion
   - The terminally exhausted (but functional) cells expanded more

4. **Myeloid Compartment is Critical**
   - PD-L1+ DCs correlate with response (providing antigen presentation)
   - CCR2+ and MMP9+ macrophages support T cell function
   - CX3CR1+ and C3+ macrophages are immunosuppressive (bad prognosis)

5. **Tumor Cell MHC Expression Matters**
   - Cancer cells expressing MHC-I and MHC-II correlate with T cell expansion
   - Antigen presentation capacity of tumors is essential

6. **CD4+ T Cells Contribute**
   - Tfh-like CD4+ T cells (BCL6+, CXCR5+) expand alongside CD8+ T cells
   - May provide help for sustained CD8+ responses
   - CXCL13 expression is shared between CD4+ and CD8+ expanders

---

## 8. Specific Genes and Pathways Highlighted

### CXCL13 Pathway (Central Finding)
- **CXCL13** is the most highlighted marker
- Expressed by both expanding CD8+ and CD4+ T cells
- Functions as a B cell-attracting chemokine
- Associated with tertiary lymphoid structure (TLS) formation
- Predictor of immunotherapy response across cancer types

### Exhaustion-Related Genes
| Gene | Protein | Function |
|------|---------|----------|
| HAVCR2 | TIM-3 | Inhibitory receptor |
| LAG3 | LAG-3 | Inhibitory receptor |
| PDCD1 | PD-1 | Target of anti-PD1 therapy |
| CTLA4 | CTLA-4 | Inhibitory receptor |
| TIGIT | TIGIT | Inhibitory receptor |
| TOX | TOX | Exhaustion transcription factor |

### Cytotoxicity Genes
| Gene | Protein | Function |
|------|---------|----------|
| PRF1 | Perforin | Pore-forming protein |
| GZMB | Granzyme B | Serine protease |
| GNLY | Granulysin | Antimicrobial |
| IFNG | IFN-γ | Key effector cytokine |

### IFN-γ Signaling Pathway
- IFNG expression by Th1 and CD8+ T cells
- Downstream effects on tumor cells
- Associated with MHC upregulation
- Part of the anti-tumor response

### Macrophage Markers
| Gene | Associated With |
|------|-----------------|
| CCR2 | Inflammatory monocyte recruitment - GOOD |
| MMP9 | Matrix remodeling - GOOD |
| CX3CR1 | Tissue-resident/suppressive - BAD |
| C3 | Complement activation - BAD (immunosuppression) |
| APOE | Immunosuppressive macrophages |

---

## Summary for Reanalysis Comparison

### Key Metrics to Validate
1. **Expansion rate**: ~1/3 of patients showed T cell clonal expansion
2. **CXCL13 expression**: Strong association with response in both CD4+ and CD8+ T cells
3. **TCF7+ cells**: Should show INVERSE correlation with expansion (unlike some other studies)
4. **Myeloid phenotypes**: PD-L1+ DCs and CCR2+/MMP9+ macrophages vs. CX3CR1+/C3+ macrophages

### Data Availability
- Data deposited in public repositories (check GEO/EBI ArrayExpress)
- 40 patients with paired biopsies
- Multi-modal: scRNA-seq + TCR-seq + CITE-seq

---

*This summary is based on the published abstract and available supplementary information from Bassez et al., Nature Medicine 2021.*
