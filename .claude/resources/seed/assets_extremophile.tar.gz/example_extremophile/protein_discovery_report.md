# Protein Discovery Report: Uncharacterized Protein AF_2201 from *Archaeoglobus fulgidus*

## 1. Selected Protein

| Property | Value |
|----------|-------|
| **UniProt Accession** | O28082 |
| **Gene Locus** | AF_2201 |
| **Organism** | *Archaeoglobus fulgidus* (strain ATCC 49558 / DSM 4304 / VC-16) |
| **Organism Type** | Hyperthermophilic sulfate-reducing archaeon (optimal growth ~83°C) |
| **Habitat** | Deep-sea hydrothermal vents, marine sediments |
| **Protein Name** | Uncharacterized protein AF_2201 |
| **Length** | 184 amino acids |
| **Review Status** | Swiss-Prot (manually reviewed) |
| **AlphaFold ID** | AF-O28082-F1 |
| **AlphaFold pLDDT** | Average 95.1 (exceptionally high confidence) |

## 2. Why This Protein Is Interesting

### Domain Architecture
This protein presents a remarkable combination of three distinct structural/functional domains:

1. **DUF2148 (Pfam: PF09918 / InterPro: IPR019224)**: A Domain of Unknown Function — genuinely uncharacterized, 
   with no experimentally determined biochemical activity. This is the core mystery domain.

2. **4Fe-4S Iron-Sulfur Cluster Binding Domain (InterPro: IPR007202)**: Contains four universally conserved 
   cysteine residues (C92, C95, C100, C118) that coordinate a [4Fe-4S] iron-sulfur cluster. Iron-sulfur 
   clusters are among the most ancient biological cofactors, involved in electron transfer, radical chemistry, 
   and enzymatic catalysis.

3. **Nitroreductase-like Fold (InterPro: IPR000415 / Gene3D: NADH Oxidase)**: The overall protein adopts a 
   fold related to nitroreductase/NADH oxidase enzymes, strongly suggesting this protein has **oxidoreductase 
   activity** — but the substrate is unknown.

### Significance
- The combination of a DUF domain with an Fe-S cluster and a redox-active fold suggests a **novel enzyme** 
  with undiscovered catalytic activity
- The exceptionally high AlphaFold confidence (95.1 average pLDDT, with catalytic Cys residues >96 pLDDT) 
  indicates a well-folded, structured protein — not a disordered fragment
- Found in a **hyperthermophilic deep-sea vent archaeon**, suggesting involvement in extremophilic metabolism
- The protein family is **ancient**, with homologs spanning both Archaea and Bacteria

## 3. Sequence

```
>O28082|AF_2201|Archaeoglobus_fulgidus
MLLNEKDFKNEGVKIAALIMAESARTAPKSKGEDTIEIVYVDGEEMEKIAAKMEEMAEGGD
KDFIRDAESVRKSQAILLIGAKGDRTVGVNCQACGFESCSEFKKADRKGENFVGPNCAFRM
IDLGIALGSAVKVSAMLGIDTRIMYRIGIAAKKLGMIDADVVMGVPLSALGKSPYFDRAPKK
```

### Key Sequence Features
- **4 Cysteine residues**: All four (C92, C95, C100, C118) coordinate the [4Fe-4S] cluster
- **CxxC...CxxxxC...C pattern**: Classic iron-sulfur cluster binding motif
- **13 Aspartate residues**: Several are universally conserved (D67, D124, D142, D179)
- **15 Glutamate residues**: High density, characteristic of thermophilic proteins
- **No histidine residues**: Unusual — rules out zinc-finger or histidine-dependent catalytic mechanisms

## 4. BLAST Search Results — Distribution Across Life

### Overview
The NCBI BLAST search (E-value < 1e-5) against the nr database revealed **200 significant hits** from 
**65 unique species**, distributed across:

| Domain of Life | Species Count | Identity Range | E-value Range |
|----------------|---------------|----------------|---------------|
| **Archaea** | 41 | 49.7–100% | 0 – 1.6e-53 |
| **Bacteria** | 24 | 48.6–55.0% | 1.9e-56 – 9.1e-53 |
| **Eukarya** | 0 | — | — |

### Archaeal Homologs (11 representative selected)
The protein is found across remarkably diverse archaeal lineages:
- **Archaeoglobales** (Archaeoglobaceae): *A. fulgidus*, *A. neptunius*, *A. veneficus*, *Ferroglobus placidus*, *Geoglobus acetivorans*
- **Bathyarchaeota** (Candidatus): Deep-branching archaeal phylum
- **Asgard Archaea**: *Candidatus Odinarchaeota*, *Candidatus Freyarchaeota* — closest archaeal relatives of eukaryotes
- **TACK Superphylum**: *Nitrososphaerota*, *Thermoprotei* (Crenarchaeota)
- **Brockarchaeota** (Candidatus): Novel deep-branching phylum

### Bacterial Homologs (10 representative selected)
Homologs span an extraordinary diversity of bacterial phyla:
- **Bacillota** (Firmicutes)
- **Pseudomonadota** (Proteobacteria): Betaproteobacteria, Deltaproteobacteria, Zetaproteobacteria
- **Spirochaetota** (Spirochaetes)
- **Chloroflexota** (Chloroflexi)
- **Planctomycetota** (Planctomycetes)
- **Atribacterota** (Candidatus — novel phylum)
- **Methylomirabilota** (Candidatus NC10)
- **Armatimonadota** (Armatimonadetes)
- **Desulfobacterota** (Desulfobacterales)

### No Eukaryotic Homologs
The complete absence of eukaryotic homologs, combined with the broad distribution across 
Archaea and Bacteria, suggests this is a **prokaryotic-specific ancient enzyme family** that was likely 
present in the **Last Universal Common Ancestor (LUCA)** or arose very early in prokaryotic evolution. 
Its absence in eukaryotes may indicate loss during the transition to aerobic metabolism, or replacement 
by analogous enzymes.

## 5. Multiple Sequence Alignment — Conservation Analysis

### Alignment Statistics
| Metric | Value |
|--------|-------|
| Sequences aligned | 21 |
| Alignment length | 196 columns |
| Positions ≥80% conserved | 68 (34.7%) |
| Positions ≥90% conserved | 55 (28.1%) |
| Universally conserved (100%) | 31 (15.8%) |
| Domain-specific positions | 0 |

### Universally Conserved Residues (100% across all 21 sequences)

#### Iron-Sulfur Cluster Binding (Essential)
| Query Position | Residue | Role |
|----------------|---------|------|
| C92 | Cysteine | **[4Fe-4S] cluster ligand** |
| C95 | Cysteine | **[4Fe-4S] cluster ligand** |
| C100 | Cysteine | **[4Fe-4S] cluster ligand** |
| C118 | Cysteine | **[4Fe-4S] cluster ligand** |

All four cysteines are the ONLY cysteine residues in the entire protein, and all are 100% conserved. 
This is the strongest possible evidence that the [4Fe-4S] cluster is absolutely essential for function.

#### Potential Catalytic Residues
| Query Position | Residue | Conservation | Potential Role |
|----------------|---------|--------------|----------------|
| D67 | Aspartate | 100% | Possible proton donor/acceptor or metal coordination |
| D124 | Aspartate | 100% | Adjacent to 4Fe-4S domain — possible substrate binding |
| D142 | Aspartate | 100% | Possible catalytic acid/base |
| D179 | Aspartate | 100% | C-terminal catalytic residue |
| K29 | Lysine | 100% | N-terminal — possible substrate anchoring |
| K134 | Lysine | 100% | Possible electrostatic stabilization |
| K174 | Lysine | 100% | C-terminal — possible catalytic base |

#### Structural Framework Residues
The universally conserved Gly, Pro, Ala, and Ile residues (G32, G81, G96, G115, G126, G130, G150, 
P28, P116, P168, A27, A128, A132, A153, I127, S131, T26, R66, R144, R180, M1) form the 
structural backbone that maintains the active site architecture.

### Key Observations

1. **The CxxC...C...C motif is absolutely invariant**: The four Cys residues binding the [4Fe-4S] cluster 
   show zero variation across all 21 sequences from diverse Archaea and Bacteria, confirming the iron-sulfur 
   cluster as the catalytic center.

2. **Conserved Asp cluster suggests acid-base catalysis**: Four universally conserved aspartate residues 
   (D67, D124, D142, D179) surround the active site, a pattern seen in many metalloenzymes where 
   carboxylate groups participate in proton transfer or substrate activation.

3. **No domain-specific conservation differences**: Despite spanning two domains of life separated by 
   ~3.5 billion years of evolution, there are ZERO positions where Archaea and Bacteria show different 
   but internally conserved residues. This extraordinary conservation suggests the protein performs an 
   identical biochemical function across all organisms.

4. **High overall conservation (34.7% positions ≥80% conserved)**: For a protein shared across two 
   domains of life, this level of conservation is remarkably high, indicating strong purifying selection 
   and essential function.

5. **Nitroreductase-like fold + Fe-S cluster**: This combination is seen in a few characterized enzymes 
   involved in **radical-mediated redox reactions**, possibly in anaerobic metabolism, cofactor biosynthesis, 
   or novel electron transfer pathways.

## 6. Hypotheses for Function

Based on the domain architecture, conservation patterns, and phylogenetic distribution, we propose 
several hypotheses:

1. **Novel Fe-S cluster oxidoreductase**: The nitroreductase-like fold combined with the [4Fe-4S] cluster 
   suggests an enzyme catalyzing a redox reaction with an unknown small molecule substrate, possibly in 
   anaerobic energy metabolism.

2. **Cofactor biosynthesis enzyme**: Many uncharacterized Fe-S proteins are involved in the biosynthesis 
   of unusual cofactors (e.g., methanogenic cofactors, modified bases). The broad distribution but 
   absence in eukaryotes is consistent with prokaryotic cofactor pathways.

3. **DNA/RNA modification enzyme**: The conserved Asp/Lys residues and Fe-S cluster resemble the 
   architecture of some radical SAM-like enzymes involved in nucleic acid modifications, though this 
   protein lacks the canonical radical SAM CxxxCxxC motif.

4. **Sulfur metabolism**: Given that the protein originates from a sulfate-reducing archaeon and has 
   broad distribution in anaerobic organisms, it may participate in sulfur compound transformations.

## 7. Files Generated

| File | Description |
|------|-------------|
| `extremophile_homologs.fasta` | FASTA file with all 21 sequences (query + 20 homologs) |
| `extremophile_msa.fasta` | MAFFT multiple sequence alignment (aligned FASTA format) |
| `homolog_summary.csv` | Summary table: accession, species, domain, identity, E-value, annotation |
| `msa_conservation_plot.png` | Conservation barplot visualization of the MSA |
| `protein_discovery_report.md` | This report |

## 8. Recommended Next Steps

1. **Experimental characterization**: Express and purify from *E. coli* (with Fe-S cluster reconstitution); 
   test for oxidoreductase activity with various substrates (NADH, NADPH, FMN, FAD)
2. **Structure determination**: The high-confidence AlphaFold model (AF-O28082-F1, pLDDT=95.1) can guide 
   crystallization; dock potential substrates into the predicted active site
3. **Genomic context analysis**: Examine the gene neighborhood of AF_2201 in *A. fulgidus* and homologs 
   in other species to infer function through operon/pathway association
4. **Phylogenetic analysis**: Build a maximum-likelihood tree to trace the evolutionary history and 
   potential horizontal gene transfer events
5. **Knockout/complementation studies**: If a genetic system exists for *A. fulgidus* or related organisms, 
   deletion of this gene could reveal phenotypic consequences

---
*Report generated by automated protein discovery pipeline*
*Query: O28082 (AF_2201) from Archaeoglobus fulgidus*
*BLAST database: NCBI nr | MSA method: MAFFT (auto)*
