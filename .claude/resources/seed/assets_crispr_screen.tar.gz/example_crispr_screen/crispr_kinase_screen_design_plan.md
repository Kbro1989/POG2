# CRISPR Kinase Knockout Screen — Complete Design Plan

## Executive Summary

This document presents a complete design plan for a genome-wide CRISPR knockout screen
targeting all human protein kinases. The plan integrates:

1. **Comprehensive kinome gene list** (623 kinase genes from Ensembl/BioMart)
2. **sgRNA design framework** with demonstrated candidate identification pipeline
3. **Literature-backed best practices** for guide selection and off-target prediction
4. **Library construction protocol** with validated oligo architecture
5. **Sequencing depth and cell number calculations**

---

## 1. Target Gene Set: The Human Kinome

**Total kinase genes identified: 623**

| Kinase Subfamily          | Count |
|---------------------------|-------|
| Serine/Threonine Kinase   | 366   |
| Dual-specificity Kinase   | 73    |
| Receptor Tyrosine Kinase  | 63    |
| Other/Unclassified Kinase | 50    |
| Non-receptor Tyrosine Kinase | 36 |
| Lipid Kinase              | 35    |

**Data source:** Ensembl BioMart (hsapiens_gene_ensembl), queried using GO:0004672
(protein kinase activity) closure + lipid kinase GO terms.

**Artifact:** `human_kinome_complete.csv` — Complete gene list with Ensembl IDs,
gene symbols, chromosomal locations, subfamily classification, and canonical transcript IDs.

---

## 2. Recommended Library Architecture

| Component                   | Count | Details |
|-----------------------------|-------|---------|
| Kinase-targeting sgRNAs     | 3,738 | 623 genes × 6 guides/gene |
| Non-targeting controls      | 500   | Scrambled sequences, no genomic match |
| Essential gene controls (+) | 150   | CEG2 set (ribosomal proteins, proteasome) |
| Non-essential controls (−)  | 150   | Olfactory receptors |
| Safe-harbor controls        | 100   | AAVS1, ROSA26 targeting |
| **TOTAL**                   | **4,638** | |

---

## 3. sgRNA Design Criteria

### Selection Rules (Literature-backed)
- **On-target scoring:** Rule Set 2 / Azimuth (Doench et al. 2016)
- **GC content:** 40–70% (optimal for SpCas9 activity)
- **No TTTT:** Poly-T terminates U6 promoter transcription
- **CDS position:** Target first 5–65% (earlier = more effective knockout)
- **Exon selection:** Constitutive exons present in all isoforms
- **Kinase domain:** ≥2 guides per gene targeting the catalytic domain
- **PAM:** NGG (SpCas9)

### Off-Target Filtering Pipeline
1. **Cas-OFFinder** — enumerate all sites with ≤3 mismatches + ≤1 bulge
2. **CFD score** — reject guides with aggregate CFD > 0.9 for any off-target
3. **Exclusion:** Reject any guide with 0–1 mismatch off-targets in coding regions
4. **GuideScan2** — library-scale specificity verification

### Demonstration Results (20 representative kinases)
- **8,539** total candidate sgRNA sites identified
- **3,366** (39.4%) pass all basic filters
- Average GC content of passing guides: **55.5%**
- All 20 genes have abundant high-quality candidates (40–532 per gene)

**Artifact:** `kinase_sgrna_candidates.csv` — 8,539 candidate guides for 20 kinases
with GC content, position, exon, and filter status.

---

## 4. Library Construction Protocol

### Oligo Architecture (74 nt total)
```
5'-TGGAAAGGACGAAACACCG-[20nt guide]-GTTTTAGAGCTAGAAATAGCAAGTTAAAATAAGGC-3'
   |── 5' adapter (19nt)──|  (20nt)  |────── 3' scaffold overlap (35nt) ──────|
```

### Cloning Workflow (BsmBI Restriction-Ligation into lentiCRISPRv2)
1. Digest lentiCRISPRv2 backbone with BsmBI-v2 (55°C, 3h)
2. Gel-purify linearized backbone (~12.9 kb)
3. PCR amplify oligo pool (Q5 HiFi, 12–16 cycles, 8–12 parallel reactions)
4. BsmBI-digest PCR product → ACCG/AAAC overhangs
5. Ligate (3:1 insert:vector, T4 ligase, 16°C overnight)
6. Electroporate into Endura cells (≥50× library representation)
7. Grow at 30°C (critical for LTR stability)
8. Maxiprep → sequence QC (≥500× coverage)

### QC Targets
| Metric | Target | Acceptable |
|--------|--------|------------|
| sgRNA representation | ≥99.5% detected | ≥99% |
| Zero-count sgRNAs | <0.5% | <1% |
| Gini index | <0.1 | <0.2 |
| Skew ratio (90th/10th) | <6 | <10 |

**Artifacts:** `twist_oligo_order_template.csv`, `kinase_library_construction_protocol.md`

---

## 5. Screening Parameters

### Cell & Virus Requirements
| Parameter | Value |
|-----------|-------|
| MOI | 0.3 |
| Transduction efficiency | ~26% |
| Cell representation | 500× per sgRNA |
| Transduced cells needed | 2,319,000 |
| Total cells to transduce | ~8,950,000 |
| Cells maintained per passage | ≥2,319,000 |

### Sequencing Requirements
| Parameter | Value |
|-----------|-------|
| Recommended depth | 300× per sgRNA per sample |
| Reads per sample | 1.4M |
| Number of samples | 4 (T0 + endpoint × 2 replicates) |
| Total reads | 5.6M |
| Sequencer | NextSeq 2000 P2 (fraction of a run) |

### Screen Timeline
| Day | Step |
|-----|------|
| D-21 | Establish Cas9-expressing cell line |
| D-14 | Validate Cas9 activity (>80% cutting) |
| D-7 | Produce lentivirus (HEK293T) |
| D-3 | Titer virus |
| D0 | Transduce ~9M cells at MOI 0.3 |
| D1-3 | Puromycin selection |
| D3 | Collect T0 reference sample |
| D3-21 | Culture with ≥500× representation |
| D14-21 | Collect endpoint samples |
| D21-28 | gDNA extraction → PCR → sequencing |
| D28-35 | Analysis (MAGeCK / BAGEL2) |

---

## 6. Data Analysis Recommendations

- **Primary analysis:** MAGeCK-RRA (Li et al. 2014) for gene-level hit calling
- **Alternative:** BAGEL2 (Kim & Hart 2021) for Bayesian essential gene identification
- **Integrative:** MAGeCKFlute (Wang et al. 2019) for pathway-level interpretation
- **QC benchmark:** Compare essential/non-essential control separation (AUROC > 0.9)
- **Visualization:** Volcano plots, ranked gene plots, pathway enrichment

---

## 7. Cost Estimate

| Item | Cost |
|------|------|
| Oligo pool synthesis (Twist Bioscience) | $460–$700 |
| Library cloning consumables | $500–$1,000 |
| Sequencing (4 samples, NextSeq) | $1,500–$2,500 |
| Lentivirus production | $300–$500 |
| Cell culture consumables | $200–$500 |
| **TOTAL** | **~$3,000–$5,500** |

---

## 8. Key References

1. Doench et al. (2016) *Nat Biotechnol* — Rule Set 2/Azimuth + CFD score
2. Sanson et al. (2018) *Nat Commun* — Brunello optimized library design
3. Hart et al. (2017) *G3* — TKOv3 library, screen design parameters
4. Shalem et al. (2014) *Science* — First genome-wide CRISPR screen
5. Joung et al. (2017) *Nat Protocols* — Comprehensive screening protocol
6. Bae et al. (2014) *Bioinformatics* — Cas-OFFinder
7. Tsai et al. (2015) *Nat Biotechnol* — GUIDE-seq off-target validation
8. Li et al. (2014) *Genome Biol* — MAGeCK analysis
9. Sanjana et al. (2014) *Nat Methods* — lentiCRISPRv2 system

---

## Artifacts Summary

| Filename | Description |
|----------|-------------|
| `human_kinome_complete.csv` | 623 kinase genes with classifications |
| `human_kinome_summary.png` | Kinome subfamily/chromosome visualization |
| `kinase_sgrna_candidates.csv` | 8,539 sgRNA candidates for 20 example kinases |
| `kinase_sgrna_analysis.png` | sgRNA analysis visualization |
| `crispr_kinase_screen_design_review.md` | Comprehensive literature review |
| `twist_oligo_order_template.csv` | Twist Bioscience oligo order template |
| `kinase_library_construction_protocol.md` | Detailed construction protocol |
| `library_construction_workflow.png` | Cloning workflow diagram |
| `screen_planning_calculator.png` | Sequencing/cell number calculator |
| `crispr_kinase_screen_design_plan.md` | This summary document |
