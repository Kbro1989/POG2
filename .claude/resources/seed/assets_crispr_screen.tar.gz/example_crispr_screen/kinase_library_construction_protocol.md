# CRISPR Kinase Knockout sgRNA Library Construction Protocol
## Comprehensive Guide for Array-Based Oligo Pool Cloning into lentiCRISPRv2

---

## 1. LIBRARY OVERVIEW

| Parameter | Value |
|-----------|-------|
| Target genes | 623 human kinase genes |
| Guides per gene | 6–10 (aim for 8 average) |
| Targeting sgRNAs | ~4,984 (623 × 8) |
| Non-targeting controls | ~500 (scrambled, no genomic match) |
| Essential gene controls | ~150 (positive controls for dropout screens) |
| Non-essential gene controls | ~150 (negative controls) |
| **Total library size** | **~5,784 sgRNAs** |
| Vector system | lentiCRISPRv2 (Addgene #52961) |
| Cloning method | BsmBI restriction-ligation |
| Oligo synthesis platform | Twist Bioscience oligo pool |

### sgRNA Design Criteria (Applied During Guide Selection)
- 20 nt spacer + NGG PAM
- GC content: 40–70%
- No TTTT (pol III terminator signal)
- Target first 50% of CDS
- Target constitutive exons (present in >80% of transcripts)
- No BsmBI sites (CGTCTC/GAGACG) in the full oligo

---

## 2. OLIGO DESIGN FOR ARRAY-BASED SYNTHESIS

### 2.1 Oligo Architecture

Each oligo in the pool has the following structure (74 nt total):

```
5'-TGGAAAGGACGAAACACCG-[20nt guide]-GTTTTAGAGCTAGAAATAGCAAGTTAAAATAAGGC-3'
   |--- 5' adapter ---|              |---------- 3' scaffold overlap ---------|
        (19 nt)              (20 nt)                    (35 nt)
```

| Component | Sequence (5'→3') | Length | Function |
|-----------|-----------------|--------|----------|
| 5' adapter | `TGGAAAGGACGAAACACCG` | 19 nt | Matches U6 promoter 3' end in lentiCRISPRv2; serves as forward PCR primer binding site |
| Guide spacer | Variable (20 nt) | 20 nt | Target-specific sgRNA sequence |
| 3' scaffold overlap | `GTTTTAGAGCTAGAAATAGCAAGTTAAAATAAGGC` | 35 nt | Matches sgRNA scaffold 5' end in lentiCRISPRv2; serves as reverse PCR primer binding site |
| **Total** | | **74 nt** | |

### 2.2 How the Oligo Integrates into the Vector

The lentiCRISPRv2 vector contains a "filler" (stuffer) sequence flanked by two BsmBI sites
between the U6 promoter and the sgRNA scaffold:

```
lentiCRISPRv2 (around cloning site):

    ...U6 promoter-ACCG----[filler/stuffer]----GTTT-sgRNA scaffold...
                   ^^^^                        ^^^^
              BsmBI overhang              BsmBI overhang
              (4 nt, 5' of guide)         (4 nt, 3' of guide)
```

After BsmBI digestion and filler removal, the linearized vector has these overhangs:
- 5' overhang: `5'-ACCG-3'` (from U6 promoter side)
- 3' overhang: `5'-AAAC-3'` (from scaffold side)

The PCR-amplified, BsmBI-digested oligo insert generates complementary overhangs:
- Insert 5' end: `5'-ACCG[20nt guide]-3'`
- Insert 3' end: `3'-[20nt guide complement]CAAA-5'`

### 2.3 Synthesis Constraints for Full Oligos

| Check | Threshold | Our Oligos |
|-------|-----------|-----------|
| Oligo length | Twist pool: up to 300 nt | 74 nt ✓ |
| GC content (full oligo) | 25–75% | 39–45% (typical) ✓ |
| Homopolymer runs | ≤6 nt preferred | Screen guides for TTTT ✓ |
| BsmBI sites in oligo | Must be absent | Pre-screened ✓ |
| Internal TTTT in guide | Must be absent (pol III terminator) | Pre-screened ✓ |

### 2.4 Naming Convention

```
KinaseLib_[GENE]_sg[N]     — targeting guides (e.g., KinaseLib_BRAF_sg1)
KinaseLib_NT_ctrl_[N]      — non-targeting controls
KinaseLib_Ess_[GENE]_sg[N] — essential gene positive controls
KinaseLib_NonE_[GENE]_sg[N] — non-essential gene negative controls
```

---

## 3. CLONING STRATEGY: BsmBI Restriction-Ligation into lentiCRISPRv2

### 3.1 Materials Required

| Reagent | Supplier | Catalog # | Notes |
|---------|----------|-----------|-------|
| lentiCRISPRv2 | Addgene | #52961 | Get ≥50 µg maxiprep |
| BsmBI-v2 (Esp3I) | NEB | R0739L | High-fidelity version |
| T4 DNA Ligase | NEB | M0202L | High-concentration |
| Q5 Hot Start HiFi Polymerase | NEB | M0493L | For oligo pool PCR |
| Endura ElectroCompetent Cells | Lucigen | 60242-2 | High-efficiency, recombination-deficient |
| CutSmart Buffer | NEB | B6004S | For BsmBI digestion |
| T4 DNA Ligase Buffer | NEB | B0202S | Includes ATP |
| Antarctic Phosphatase | NEB | M0289L | Optional: dephosphorylation |
| Ampicillin | — | — | 100 µg/mL |
| SOC medium | — | — | For recovery |

### 3.2 Step-by-Step Protocol

#### STEP 1: Backbone Preparation — BsmBI Digestion of lentiCRISPRv2

**Purpose:** Remove the stuffer/filler sequence to create a linearized backbone with compatible 4-nt overhangs.

```
Reaction (50 µL):
  lentiCRISPRv2 plasmid    5 µg
  10× CutSmart Buffer      5 µL
  BsmBI-v2 (10 U/µL)       3 µL (30 U)
  Nuclease-free H₂O        to 50 µL

Incubation:
  55°C for 3 hours (or overnight for complete digestion)
  Heat-inactivate: 80°C for 20 min
```

**Post-digestion processing:**
1. Run on 0.8% agarose gel — expect ~12.9 kb linearized band + ~2 kb stuffer fragment
2. Gel-extract the ~12.9 kb band (use Monarch DNA Gel Extraction Kit or equivalent)
3. **Optional but recommended:** Treat with Antarctic Phosphatase to prevent self-ligation
   ```
   Gel-purified backbone    ~1 µg
   Antarctic Phosphatase    1 µL
   37°C for 30 min, then 80°C for 2 min (inactivate)
   ```
4. Quantify by Nanodrop and Qubit — need ≥1 µg for library ligation

**QC checkpoint:** Verify complete digestion by running uncut vs. BsmBI-cut on gel. Uncut should show supercoiled bands; cut should show single ~12.9 kb linear band.

#### STEP 2: Oligo Pool PCR Amplification

**Purpose:** Amplify the synthesized oligo pool to generate sufficient dsDNA insert material with flanking BsmBI sites.

**PCR Primers (add BsmBI sites for subsequent cloning):**

```
Forward primer (ArrayF):
  5'-TAACTTGAAAGTATTTCGATTTCTTGGCTTTATATATCTTGTGGAAAGGACGAAACACCG-3'
                                                |--oligo 5' adapter--|
  Length: 59 nt
  Contains: Upstream context + overlap with U6 promoter 3' end

Reverse primer (ArrayR):
  5'-ACTTTTTCAAGTTGATAACGGACTAGCCTTATTTTAACTTGCTATTTCTAGCTCTAAAAC-3'
                                        |---RC of oligo 3' scaffold---|
  Length: 60 nt
  Contains: Downstream scaffold context (reverse complement)
```

**CRITICAL NOTE on primer design:** The primers above include flanking sequences from lentiCRISPRv2 that contain the BsmBI recognition sites. This means PCR amplification yields a product that, after BsmBI digestion, produces inserts with the correct 4-nt overhangs (ACCG/AAAC) complementary to the digested backbone. 

**Alternative simplified primers (if using a two-step cloning approach):**
```
Simple Forward: 5'-TGGAAAGGACGAAACACCG-3' (19 nt, Tm ~58°C)
Simple Reverse: 5'-GCCTTATTTTAACTTGCTATTTCTAGCTCTAAAAC-3' (35 nt, exact RC of scaffold overlap)
```
These simpler primers amplify just the 74-nt oligo to ~74 bp dsDNA, but require the longer primers above in a nested PCR or require a different BsmBI-flanked strategy.

**PCR Reaction (50 µL):**

```
Template (Twist oligo pool)    ~10 ng (diluted from pool)
Q5 HiFi 2× Master Mix         25 µL
Forward primer (10 µM)         2.5 µL
Reverse primer (10 µM)         2.5 µL
Nuclease-free H₂O              to 50 µL

Cycling:
  98°C    30 sec     (initial denaturation)
  [98°C   10 sec     (denaturation)
   63°C   30 sec     (annealing)
   72°C   15 sec]    (extension)
  × 12-16 cycles     ← CRITICAL: Minimize cycles to reduce bias
  72°C    2 min      (final extension)
  4°C     hold
```

**⚠️ CRITICAL NOTES on PCR:**
- **Use only 12–16 cycles** — higher cycle numbers introduce amplification bias
  favoring GC-moderate sequences and create PCR duplicates
- **Set up 8–12 parallel 50 µL reactions** and pool to reduce stochastic bias
- **Use Q5 or KAPA HiFi** polymerase — high fidelity (error rate ~10⁻⁶) essential
  to avoid introducing mutations
- **Do NOT use Taq** — error rate too high for library work
- Optimize by testing 10, 12, 14, 16 cycles on a small aliquot first
- Expect product at ~140–150 bp (with the full-length primers) or ~74 bp (simple primers)

**Post-PCR processing:**
1. Pool all parallel reactions
2. Run 2 µL on 4% agarose or 10% TBE-PAGE gel — verify single band at expected size
3. **Column purify** (Monarch PCR Cleanup Kit) or **gel extract** if non-specific bands present
4. Quantify by Qubit (dsDNA HS assay)
5. Need ~500 ng–1 µg of purified PCR product

#### STEP 3: BsmBI Digestion of PCR Amplicons

**Purpose:** Generate compatible 4-nt sticky ends on the amplified inserts.

```
Reaction (50 µL):
  Purified PCR product     500 ng – 1 µg
  10× CutSmart Buffer     5 µL
  BsmBI-v2                 2 µL (20 U)
  Nuclease-free H₂O       to 50 µL

Incubation:
  55°C for 1–2 hours
  Heat-inactivate: 80°C for 20 min
```

**Post-digestion:**
1. Column purify to remove small flanking fragments and enzyme
2. Quantify by Qubit

**Expected product:** ~24 bp insert (ACCG + 20nt guide) with compatible overhangs:
```
  5'-ACCG[20nt guide]-3'
      3'-[20nt guide complement]CAAA-5'
```

#### STEP 4: Ligation

**Purpose:** Ligate the BsmBI-digested insert pool into the linearized, dephosphorylated backbone.

```
Reaction (20 µL):
  BsmBI-cut backbone (dephosphorylated)    50 ng
  BsmBI-cut insert pool                    ~3-fold molar excess*
  10× T4 Ligase Buffer                    2 µL
  T4 DNA Ligase (400 U/µL)               1 µL
  Nuclease-free H₂O                       to 20 µL

* Molar ratio calculation:
  Backbone: ~12.9 kb → 50 ng = ~5.9 fmol
  Insert: ~0.024 kb → at 3:1 molar ratio = ~17.7 fmol = ~0.28 ng
  (In practice, use ~1 ng insert to account for losses)

Incubation:
  16°C overnight (or room temperature for 2 hours)
  Heat-inactivate: 65°C for 10 min
```

**Controls:**
- **No-insert control:** Backbone + ligase, no insert → measures self-ligation/background
- **No-ligase control:** Backbone + insert, no ligase → measures uncut backbone carryover

#### STEP 5: Electroporation into Endura Electrocompetent Cells

**Purpose:** Transform the ligation at high efficiency to achieve ≥50× library representation.

```
Transformation:
  1. Desalt ligation: drop dialyze on 0.025 µm membrane against H₂O for 20 min
     (OR ethanol precipitate and resuspend in 5 µL H₂O)
  2. Thaw Endura cells on ice (25 µL per transformation)
  3. Add 2 µL desalted ligation to 25 µL cells
  4. Transfer to 1 mm electroporation cuvette
  5. Electroporate: 1.8 kV, 200 Ω, 25 µF (standard E. coli settings)
  6. Immediately add 975 µL warm SOC medium
  7. Recover at 37°C, 225 rpm for 1 hour
```

**Plating for colony counting:**
```
  Serial dilutions: plate 1 µL, 10 µL, 100 µL on LB-Amp plates
  Plate remainder on large LB-Amp plates (or in liquid culture*)
  
  Incubate 37°C for 12–14 hours (NOT longer — prevent satellite colonies)
```

**Representation calculation:**

```
  Library size:                    ~5,784 sgRNAs
  Minimum representation:          50× (industry standard)
  Required colonies:               5,784 × 50 = 289,200 colonies minimum
  Target colonies:                 5,784 × 200 = ~1,157,000 (recommended for 200×)
  
  Typical Endura efficiency:       ~10⁹ CFU/µg pUC19
  Expected with library ligation:  ~10⁷–10⁸ CFU total (per transformation)
  
  → Plan 2–4 electroporations to comfortably exceed 500,000 colonies
```

**⚠️ If colony count is too low:**
- Increase number of electroporation reactions (up to 10)
- Optimize backbone:insert ratio
- Verify BsmBI digestion completion
- Consider chemical transformation with NEB Stable cells (lower efficiency but simpler)

#### STEP 6: Harvest and Maxiprep

```
  Option A (plate-based): Scrape all colonies from plates with LB + 20% glycerol
  Option B (liquid culture — PREFERRED for libraries):
    1. Inoculate recovery directly into 500 mL LB-Amp
    2. Grow at 30°C (NOT 37°C) for 12–16 hours
       → 30°C reduces recombination of lentiviral LTRs
    3. Harvest by centrifugation
    4. Maxiprep (Qiagen HiSpeed or ZymoPURE II)
    5. Expected yield: 500–2000 µg from 500 mL culture
```

**⚠️ CRITICAL: Grow at 30°C** for lentiviral vectors to minimize recombination between LTRs.

**Glycerol stocks:** Save aliquots of the bacterial culture:
```
  Mix 500 µL culture + 500 µL 50% glycerol
  Store at −80°C (multiple aliquots for re-growth if needed)
```

---

## 4. QUALITY CONTROL (QC) PIPELINE

### 4.1 PCR Amplification QC

| Check | Method | Expected Result | Action if Failed |
|-------|--------|-----------------|-----------------|
| Product size | 4% agarose or 10% TBE-PAGE | Single band at ~74 bp (simple primers) or ~140-150 bp (extended primers) | Optimize annealing temp, reduce cycles |
| Product purity | Gel visualization | No primer dimers, no non-specific bands | Gel-extract correct band |
| Yield | Qubit dsDNA HS | ≥500 ng total from pooled reactions | Increase parallel reactions |

### 4.2 Plasmid Library Sequencing QC

**Method:** Amplicon sequencing (NGS) of the sgRNA cassette region

**Amplicon PCR for sequencing:**
```
Forward: 5'-AATGGACTATCATATGCTTACCGTAACTTGAAAGTATTTCG-3'
  (binds upstream of U6 promoter)
Reverse: 5'-CTTTAGTTTGTATGTCTGTTGCTATTATGTCTACTATTCTTTCC-3'
  (binds downstream of scaffold)

Product: ~270 bp amplicon containing the 20nt guide
```

**Sequencing requirements:**
```
  Platform:           Illumina MiSeq/NextSeq (or NovaSeq for large libraries)
  Read length:        Single-end 75 bp or paired-end 2×75 bp is sufficient
  Minimum coverage:   500× per sgRNA (= 5,784 × 500 = ~2.9 million reads)
  Recommended:        1,000× per sgRNA (= ~5.8 million reads)
```

### 4.3 Key QC Metrics and Targets

| Metric | Target | Acceptable | Action if Failed |
|--------|--------|------------|-----------------|
| **sgRNA representation** | ≥99.5% detected | ≥99% | Increase colony count; re-clone |
| **Zero-count sgRNAs** | <0.5% (≤29 sgRNAs) | <1% | If systematic, check oligo pool quality |
| **Gini index** | <0.1 (perfect = 0) | <0.2 | Re-amplify with fewer PCR cycles |
| **Skew ratio** (90th/10th percentile) | <6 | <10 | Reduce PCR cycles; optimize transformation |
| **Fold-change top/bottom 10%** | <4 | <10 | As above |
| **Log2 fold-change SD** | <0.5 | <1.0 | Indicates uniform representation |

### 4.4 Detailed QC Analysis Steps

#### A. Read Mapping
```
1. Trim reads to extract 20-nt guide region
   (Use cutadapt to trim adapter and scaffold sequences)
2. Map exact matches to the designed guide library
   (Use bowtie2 with --very-sensitive or exact match with custom script)
3. Count reads per sgRNA
4. Calculate normalized counts (reads per million)
```

#### B. Uniformity Assessment
```python
# Example QC analysis code
import numpy as np
import pandas as pd

# Read counts per sgRNA
counts = pd.read_csv("sgRNA_counts.csv")

# Basic statistics
total_reads = counts['count'].sum()
mean_count = counts['count'].mean()
median_count = counts['count'].median()

# Zero-count sgRNAs
zero_count = (counts['count'] == 0).sum()
zero_pct = zero_count / len(counts) * 100
print(f"Zero-count sgRNAs: {zero_count} ({zero_pct:.2f}%)")

# Gini index
def gini_index(array):
    array = np.sort(array)
    n = len(array)
    index = np.arange(1, n + 1)
    return (2 * np.sum(index * array) / (n * np.sum(array))) - (n + 1) / n

gini = gini_index(counts['count'].values)
print(f"Gini index: {gini:.4f}")

# Skew ratio (90th/10th percentile)
p90 = np.percentile(counts['count'], 90)
p10 = np.percentile(counts['count'], 10)
skew_ratio = p90 / p10
print(f"Skew ratio (90/10): {skew_ratio:.2f}")
```

#### C. Control Validation
```
- Non-targeting controls: Should have no phenotypic effect; serves as 
  baseline for fold-change calculations
- Essential gene controls (e.g., RPS19, RPL5, PCNA, CDK1): Should 
  drop out in proliferation screens (positive controls for screen quality)
- Non-essential gene controls (e.g., olfactory receptors, safe harbor 
  intergenic regions): Should remain unchanged (negative controls)
```

### 4.5 Restriction Digest Verification (Quick Check)

```
Diagnostic digest of maxiprep library:
  Library plasmid DNA       1 µg
  EcoRI-HF (or other       1 µL
   single-cutter)
  CutSmart Buffer           5 µL
  H₂O                      to 50 µL

  37°C for 1 hour
  
  Run on 0.8% gel:
  - Expect: Clean band at ~14 kb (linearized lentiCRISPRv2 with insert)
  - Concern: Multiple bands indicate rearrangement
```

---

## 5. LIBRARY COMPOSITION SUMMARY

### 5.1 Component Breakdown

| Category | Count | Purpose |
|----------|-------|---------|
| Kinase-targeting sgRNAs | ~4,984 | 623 genes × 8 guides/gene |
| Non-targeting controls | 500 | Negative controls (random sequences, no genomic match) |
| Essential gene controls | 150 | Positive dropout controls (RPS19, RPL5, etc.) |
| Non-essential gene controls | 150 | Negative phenotype controls |
| **TOTAL** | **~5,784** | |

### 5.2 Twist Oligo Pool Order Specifications

| Parameter | Value |
|-----------|-------|
| Oligo length | 74 nt (uniform) |
| Pool size | 5,784 oligos |
| Synthesis scale | Oligo pool (standard) |
| Format | Dried, pooled DNA |
| Amount | ~2-10 pmol per oligo (depends on pool size tier) |
| Estimated cost | ~$0.05-0.10/oligo for pools = ~$290-580 |
| Turnaround | ~2-3 weeks |

### 5.3 Alternative: Individual Oligo Ordering (NOT Recommended for Libraries)

For reference only — ordering 5,784 individual oligos would cost ~$100K+.
Array-synthesized pools are the only practical approach for libraries.

---

## 6. TIMELINE AND COST ESTIMATE

### 6.1 Timeline

| Step | Duration | Cumulative |
|------|----------|------------|
| Oligo pool order (Twist) | 2–3 weeks | Week 3 |
| Backbone preparation | 1 day | Week 3 |
| Oligo pool PCR + QC | 1 day | Week 3 |
| BsmBI digest + ligation | 1 day | Week 3 |
| Electroporation + plating | 1 day | Week 3 |
| Colony counting + harvest | 1–2 days | Week 4 |
| Maxiprep | 1 day | Week 4 |
| Sequencing QC (submit + analysis) | 1–2 weeks | Week 5–6 |
| **Total** | **~5–6 weeks** | |

### 6.2 Cost Estimate

| Item | Estimated Cost |
|------|---------------|
| Twist oligo pool (~5,784 × 74 nt) | $300–600 |
| lentiCRISPRv2 (Addgene) | $75 |
| Enzymes + reagents (BsmBI, ligase, polymerase) | $200–400 |
| Endura electrocompetent cells (2–4 rxns) | $200–400 |
| Maxiprep kit | $50–100 |
| NGS sequencing (MiSeq, ~6M reads) | $300–800 |
| **Total** | **$1,125–2,375** |

---

## 7. TROUBLESHOOTING GUIDE

| Problem | Likely Cause | Solution |
|---------|-------------|----------|
| Low colony count (<50× representation) | Poor ligation; incomplete digestion | Verify BsmBI digestion on gel; increase insert:vector ratio; use more cells |
| High background (no-insert control has many colonies) | Incomplete backbone digestion; no dephosphorylation | Re-digest backbone; add Antarctic Phosphatase step |
| Skewed representation (Gini >0.2) | Too many PCR cycles; stochastic bottleneck | Reduce to 10–12 cycles; increase parallel reactions; increase template |
| Many zero-count sgRNAs (>1%) | Oligo pool synthesis failure; cloning bias | Check oligo pool by sequencing before cloning; verify no systematic sequence features in missing guides |
| Rearranged plasmids | Recombination in bacteria | Use Endura (recA⁻) cells; grow at 30°C; limit growth time |
| Wrong-size PCR product | Mispriming; contamination | Redesign primers; use fresh template; gel-extract correct band |
| Multiple bands in diagnostic digest | Mixed population; rearrangements | Re-clone from glycerol stock with fresh backbone |

---

## 8. REFERENCES AND RESOURCES

1. Joung et al. (2017) "Genome-scale CRISPR-Cas9 knockout and transcriptional activation screening." *Nature Protocols* 12:828–863.
2. Sanjana et al. (2014) "Improved vectors and genome-wide libraries for CRISPR screening." *Nature Methods* 11:783–784.
3. Doench et al. (2016) "Optimized sgRNA design to maximize activity and minimize off-target effects of CRISPR-Cas9." *Nature Biotechnology* 34:184–191.
4. lentiCRISPRv2 map: https://www.addgene.org/52961/
5. Twist Bioscience oligo pools: https://www.twistbioscience.com/products/oligopools

---

*Protocol version: 1.0*
*Generated for: CRISPR Kinase Knockout Library Project*
*Vector: lentiCRISPRv2 (Addgene #52961)*
*Library size: ~5,784 sgRNAs*
